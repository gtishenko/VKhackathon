self.__precacheManifest = [
  {
    "revision": "13fe2c02f17707d992fd",
    "url": "/static/css/main.bafb5aa5.chunk.css"
  },
  {
    "revision": "13fe2c02f17707d992fd",
    "url": "/static/js/main.bce20600.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "0fd9c881cd3d53c35d07",
    "url": "/static/css/2.9d2b281e.chunk.css"
  },
  {
    "revision": "0fd9c881cd3d53c35d07",
    "url": "/static/js/2.f489f33e.chunk.js"
  },
  {
    "revision": "385272d8ba3094d222a6efe2c9b669d9",
    "url": "/index.html"
  }
];